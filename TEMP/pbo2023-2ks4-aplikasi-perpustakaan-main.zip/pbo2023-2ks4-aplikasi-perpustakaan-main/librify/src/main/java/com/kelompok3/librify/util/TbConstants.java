/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kelompok3.librify.util;

/**
 *
 * @author Kel 3
 */
public class TbConstants {
        public static interface Roles {
        String USER = "ROLE_USER";
        String ADMIN = "ROLE_ADMIN";
    }
}
