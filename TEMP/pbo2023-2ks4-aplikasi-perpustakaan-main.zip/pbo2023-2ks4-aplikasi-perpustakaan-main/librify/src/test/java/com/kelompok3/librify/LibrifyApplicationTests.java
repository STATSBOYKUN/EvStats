package com.kelompok3.librify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
