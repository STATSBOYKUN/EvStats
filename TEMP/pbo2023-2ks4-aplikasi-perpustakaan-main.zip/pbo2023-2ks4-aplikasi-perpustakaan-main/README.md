# PBO2023-2KS4-Aplikasi Perpustakaan

```
      [ KELOMPOK 3 PBO KELAS 2KS4 ]
            ANGGOTA KELOMPOK :

- Aditya Widiyanto Nugroho  (222111845)
- Azmi Zulfani Putri        (222111940)
- Fathimah Az-Zahra         (222112047)
- Himawan Wahid Ikhwansyah  (222112094)
- R.Faras Roihan Armel      (222112296)
- Zidan Al Azizi            (222112433)
- Nabila Widya Putri        (222112236)
- Ni Putu Sancita M. A.     (222112258)
```
## Description
Tugas Kelompok 3 Praktikum Berorientasi Objek Studi Kasus Aplikasi Perpustakaan.

## Daftar Isi
- [UML Diagram](https://gitlab.com/Hima-1/pbo2023-2ks4-aplikasi-perpustakaan/-/tree/main/UML%20Diagram)
- [Implementasi Program](https://gitlab.com/Hima-1/pbo2023-2ks4-aplikasi-perpustakaan/-/tree/main/librify)
- [Video Demonstrasi](https://drive.google.com/file/d/1g_7sJhPFyIIlsUwdjTNbou0KUIeGUcYA/view?usp=sharing)
